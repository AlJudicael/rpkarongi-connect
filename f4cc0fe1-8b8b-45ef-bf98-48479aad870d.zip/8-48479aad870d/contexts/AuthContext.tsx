
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@/types';
import { getCurrentUser, saveCurrentUser, getUsers, saveUsers } from '@/utils/storage';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: Omit<User, 'id' | 'createdAt'> & { password: string; secretKey?: string }) => Promise<boolean>;
  logout: () => Promise<void>;
  updateUser: (userData: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_SECRET_KEY = 'RPKARONGI2025ADMIN';

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await getCurrentUser();
      setUser(currentUser);
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const users = await getUsers();
      const foundUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (!foundUser) {
        console.log('User not found');
        return false;
      }

      // In a real app, you'd verify the password hash
      // For now, we'll use a simple check (password stored in a separate field)
      const userWithPassword = users.find(u => 
        u.email.toLowerCase() === email.toLowerCase() && 
        (u as any).password === password
      );

      if (!userWithPassword) {
        console.log('Invalid password');
        return false;
      }

      await saveCurrentUser(foundUser);
      setUser(foundUser);
      return true;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const register = async (userData: Omit<User, 'id' | 'createdAt'> & { password: string; secretKey?: string }): Promise<boolean> => {
    try {
      // Validate admin secret key if role is admin
      if (userData.role === 'admin' && userData.secretKey !== ADMIN_SECRET_KEY) {
        console.log('Invalid admin secret key');
        return false;
      }

      const users = await getUsers();
      
      // Check if email already exists
      if (users.some(u => u.email.toLowerCase() === userData.email.toLowerCase())) {
        console.log('Email already exists');
        return false;
      }

      const newUser: User & { password: string } = {
        id: Date.now().toString(),
        email: userData.email,
        role: userData.role,
        firstName: userData.firstName,
        lastName: userData.lastName,
        trade: userData.trade,
        registrationNumber: userData.registrationNumber,
        createdAt: new Date().toISOString(),
        password: userData.password,
      };

      users.push(newUser);
      await saveUsers(users);

      // Auto-login after registration
      const userWithoutPassword = { ...newUser };
      delete (userWithoutPassword as any).password;
      await saveCurrentUser(userWithoutPassword);
      setUser(userWithoutPassword);

      return true;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await saveCurrentUser(null);
      setUser(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const updateUser = async (userData: Partial<User>): Promise<void> => {
    try {
      if (!user) return;

      const updatedUser = { ...user, ...userData };
      const users = await getUsers();
      const userIndex = users.findIndex(u => u.id === user.id);
      
      if (userIndex !== -1) {
        users[userIndex] = updatedUser;
        await saveUsers(users);
        await saveCurrentUser(updatedUser);
        setUser(updatedUser);
      }
    } catch (error) {
      console.error('Update user error:', error);
      throw error;
    }
  };

  const resetPassword = async (email: string): Promise<boolean> => {
    try {
      const users = await getUsers();
      const userExists = users.some(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (!userExists) {
        console.log('User not found for password reset');
        return false;
      }

      // In a real app, you'd send a password reset email
      // For now, we'll just return true to simulate success
      console.log('Password reset email sent to:', email);
      return true;
    } catch (error) {
      console.error('Password reset error:', error);
      return false;
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
