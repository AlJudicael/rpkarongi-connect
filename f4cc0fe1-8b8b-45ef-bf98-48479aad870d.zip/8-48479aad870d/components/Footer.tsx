
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, commonStyles } from '@/styles/commonStyles';

export const Footer = () => {
  return (
    <View style={styles.footer}>
      <Text style={styles.footerText}>
        Creator: SHIMIRWA N. Alain Judicael
      </Text>
      <Text style={styles.footerText}>
        RegNo: 22RP10051
      </Text>
      <Text style={styles.footerText}>
        Supervisor: UWAYEZU Theoneste
      </Text>
      <Text style={[styles.footerText, styles.copyright]}>
        © 2025 RP Karongi College. All rights reserved.
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  footer: {
    padding: 16,
    backgroundColor: colors.card,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 18,
  },
  copyright: {
    marginTop: 8,
    fontWeight: '600',
  },
});
