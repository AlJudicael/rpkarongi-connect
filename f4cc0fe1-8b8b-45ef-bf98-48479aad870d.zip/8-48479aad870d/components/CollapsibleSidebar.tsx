
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated, ScrollView } from 'react-native';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { useRouter } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';

interface MenuItem {
  id: string;
  label: string;
  icon: string;
  route: string;
  roles?: string[];
}

export const CollapsibleSidebar = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [animation] = useState(new Animated.Value(0));
  const router = useRouter();
  const { user, logout } = useAuth();

  const menuItems: MenuItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: 'house.fill', route: '/dashboard' },
    { id: 'announcements', label: 'Announcements', icon: 'megaphone.fill', route: '/announcements' },
    { id: 'timetable', label: 'Timetable', icon: 'calendar', route: '/timetable' },
    { id: 'schedule', label: 'Schedule', icon: 'clock.fill', route: '/schedule', roles: ['admin', 'staff'] },
    { id: 'users', label: 'User Management', icon: 'person.3.fill', route: '/users', roles: ['admin'] },
    { id: 'students', label: 'Students', icon: 'person.2.fill', route: '/students', roles: ['admin', 'staff'] },
    { id: 'profile', label: 'Profile', icon: 'person.circle.fill', route: '/profile' },
  ];

  const toggleSidebar = () => {
    const toValue = isExpanded ? 0 : 1;
    Animated.timing(animation, {
      toValue,
      duration: 300,
      useNativeDriver: false,
    }).start();
    setIsExpanded(!isExpanded);
  };

  const sidebarWidth = animation.interpolate({
    inputRange: [0, 1],
    outputRange: [60, 250],
  });

  const handleMenuPress = (route: string) => {
    router.push(route as any);
    if (isExpanded) {
      toggleSidebar();
    }
  };

  const handleLogout = async () => {
    await logout();
    router.replace('/');
  };

  const filteredMenuItems = menuItems.filter(item => {
    if (!item.roles) return true;
    return user && item.roles.includes(user.role);
  });

  return (
    <Animated.View style={[styles.sidebar, { width: sidebarWidth }]}>
      <TouchableOpacity style={styles.toggleButton} onPress={toggleSidebar}>
        <IconSymbol 
          name={isExpanded ? 'chevron.left' : 'line.3.horizontal'} 
          size={24} 
          color={colors.primary} 
        />
      </TouchableOpacity>

      <ScrollView style={styles.menuContainer} showsVerticalScrollIndicator={false}>
        {filteredMenuItems.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={styles.menuItem}
            onPress={() => handleMenuPress(item.route)}
          >
            <IconSymbol name={item.icon as any} size={24} color={colors.primary} />
            {isExpanded && <Text style={styles.menuLabel}>{item.label}</Text>}
          </TouchableOpacity>
        ))}

        <TouchableOpacity style={[styles.menuItem, styles.logoutButton]} onPress={handleLogout}>
          <IconSymbol name="arrow.right.square.fill" size={24} color={colors.danger} />
          {isExpanded && <Text style={[styles.menuLabel, styles.logoutText]}>Logout</Text>}
        </TouchableOpacity>
      </ScrollView>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  sidebar: {
    backgroundColor: colors.card,
    borderRightWidth: 1,
    borderRightColor: colors.border,
    paddingVertical: 20,
    boxShadow: `2px 0 8px ${colors.shadow}`,
    elevation: 5,
  },
  toggleButton: {
    padding: 15,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    marginBottom: 10,
  },
  menuContainer: {
    flex: 1,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    marginHorizontal: 8,
    marginVertical: 4,
    borderRadius: 8,
  },
  menuLabel: {
    marginLeft: 15,
    fontSize: 16,
    color: colors.text,
    fontWeight: '500',
  },
  logoutButton: {
    marginTop: 20,
  },
  logoutText: {
    color: colors.danger,
  },
});
