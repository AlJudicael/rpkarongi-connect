
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { Announcement } from '@/types';
import Animated, { FadeInDown } from 'react-native-reanimated';

interface AnnouncementCardProps {
  announcement: Announcement;
  onPress?: () => void;
  onDelete?: () => void;
  canDelete?: boolean;
  index?: number;
}

export const AnnouncementCard = ({ 
  announcement, 
  onPress, 
  onDelete, 
  canDelete = false,
  index = 0 
}: AnnouncementCardProps) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleDelete = () => {
    Alert.alert(
      'Delete Announcement',
      'Are you sure you want to delete this announcement?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: onDelete 
        },
      ]
    );
  };

  return (
    <Animated.View 
      entering={FadeInDown.delay(index * 100).springify()}
      style={styles.card}
    >
      <TouchableOpacity onPress={onPress} activeOpacity={0.7}>
        <View style={styles.header}>
          <View style={styles.iconContainer}>
            <IconSymbol name="megaphone.fill" size={24} color={colors.primary} />
          </View>
          <View style={styles.headerContent}>
            <Text style={styles.title} numberOfLines={2}>{announcement.title}</Text>
            <Text style={styles.author}>By {announcement.createdByName}</Text>
          </View>
          {canDelete && (
            <TouchableOpacity onPress={handleDelete} style={styles.deleteButton}>
              <IconSymbol name="trash.fill" size={20} color={colors.danger} />
            </TouchableOpacity>
          )}
        </View>

        <Text style={styles.content} numberOfLines={3}>
          {announcement.content}
        </Text>

        {announcement.fileUrl && (
          <View style={styles.fileIndicator}>
            <IconSymbol name="paperclip" size={16} color={colors.primary} />
            <Text style={styles.fileName}>{announcement.fileName || 'Attachment'}</Text>
          </View>
        )}

        <View style={styles.footer}>
          <Text style={styles.date}>{formatDate(announcement.createdAt)}</Text>
          {announcement.targetTrades && announcement.targetTrades.length > 0 && (
            <View style={styles.tradesContainer}>
              {announcement.targetTrades.slice(0, 2).map((trade, idx) => (
                <View key={idx} style={styles.tradeBadge}>
                  <Text style={styles.tradeText}>{trade}</Text>
                </View>
              ))}
              {announcement.targetTrades.length > 2 && (
                <Text style={styles.moreText}>+{announcement.targetTrades.length - 2}</Text>
              )}
            </View>
          )}
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  headerContent: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  author: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  deleteButton: {
    padding: 8,
  },
  content: {
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
    marginBottom: 12,
  },
  fileIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.highlight,
    padding: 8,
    borderRadius: 6,
    marginBottom: 12,
  },
  fileName: {
    fontSize: 12,
    color: colors.primary,
    marginLeft: 6,
    fontWeight: '500',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  date: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  tradesContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tradeBadge: {
    backgroundColor: colors.primary,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    marginLeft: 4,
  },
  tradeText: {
    fontSize: 10,
    color: '#ffffff',
    fontWeight: '600',
  },
  moreText: {
    fontSize: 10,
    color: colors.textSecondary,
    marginLeft: 4,
  },
});
