
export type UserRole = 'admin' | 'staff' | 'student';

export type Trade = 'IT' | 'EEE' | 'AUTO-MOBILE TECH' | 'MANUFACTURING TECHNOLOGY' | 'HOSPITALITY' | 'HORTICULTURE';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  firstName: string;
  lastName: string;
  trade?: Trade;
  registrationNumber?: string;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  fileUrl?: string;
  fileName?: string;
  fileType?: string;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  targetTrades?: Trade[];
}

export interface Timetable {
  id: string;
  trade: Trade;
  day: string;
  startTime: string;
  endTime: string;
  subject: string;
  instructor: string;
  room: string;
  createdBy: string;
  createdAt: string;
}

export interface Schedule {
  id: string;
  trade: Trade;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  createdBy: string;
  createdAt: string;
}
