
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import { Footer } from '@/components/Footer';
import { CollapsibleSidebar } from '@/components/CollapsibleSidebar';
import { getAnnouncements } from '@/utils/storage';
import { Announcement } from '@/types';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function AnnouncementDetailScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const { id } = useLocalSearchParams();
  const [announcement, setAnnouncement] = useState<Announcement | null>(null);

  useEffect(() => {
    if (!user) {
      router.replace('/');
    } else {
      loadAnnouncement();
    }
  }, [user, id]);

  const loadAnnouncement = async () => {
    try {
      const announcements = await getAnnouncements();
      const found = announcements.find(a => a.id === id);
      if (found) {
        setAnnouncement(found);
      } else {
        router.back();
      }
    } catch (error) {
      console.error('Error loading announcement:', error);
      router.back();
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleOpenFile = () => {
    if (announcement?.fileUrl) {
      Linking.openURL(announcement.fileUrl);
    }
  };

  if (!user || !announcement) return null;

  return (
    <View style={styles.container}>
      <View style={styles.mainContent}>
        <CollapsibleSidebar />
        
        <View style={styles.content}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
              <IconSymbol name="chevron.left" size={24} color={colors.primary} />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Announcement Details</Text>
          </View>

          <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
            <Animated.View entering={FadeInDown.delay(100).springify()} style={styles.card}>
              <View style={styles.iconContainer}>
                <IconSymbol name="megaphone.fill" size={32} color={colors.primary} />
              </View>

              <Text style={styles.title}>{announcement.title}</Text>

              <View style={styles.metaContainer}>
                <View style={styles.metaItem}>
                  <IconSymbol name="person.fill" size={16} color={colors.textSecondary} />
                  <Text style={styles.metaText}>{announcement.createdByName}</Text>
                </View>
                <View style={styles.metaItem}>
                  <IconSymbol name="calendar" size={16} color={colors.textSecondary} />
                  <Text style={styles.metaText}>{formatDate(announcement.createdAt)}</Text>
                </View>
              </View>

              {announcement.targetTrades && announcement.targetTrades.length > 0 && (
                <View style={styles.tradesSection}>
                  <Text style={styles.tradesLabel}>Target Trades:</Text>
                  <View style={styles.tradesContainer}>
                    {announcement.targetTrades.map((trade, index) => (
                      <View key={index} style={styles.tradeBadge}>
                        <Text style={styles.tradeText}>{trade}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}

              <View style={styles.divider} />

              <Text style={styles.content}>{announcement.content}</Text>

              {announcement.fileUrl && (
                <TouchableOpacity style={styles.fileCard} onPress={handleOpenFile}>
                  <View style={styles.fileIcon}>
                    <IconSymbol 
                      name={announcement.fileType?.includes('pdf') ? 'doc.fill' : 'photo.fill'} 
                      size={24} 
                      color={colors.primary} 
                    />
                  </View>
                  <View style={styles.fileInfo}>
                    <Text style={styles.fileName}>{announcement.fileName || 'Attachment'}</Text>
                    <Text style={styles.fileAction}>Tap to open</Text>
                  </View>
                  <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
                </TouchableOpacity>
              )}
            </Animated.View>
            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </View>
      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: 16,
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 24,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 3,
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 16,
    lineHeight: 36,
  },
  metaContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    marginBottom: 16,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  metaText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  tradesSection: {
    marginBottom: 16,
  },
  tradesLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  tradesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tradeBadge: {
    backgroundColor: colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  tradeText: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '600',
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: 20,
  },
  content: {
    fontSize: 16,
    color: colors.text,
    lineHeight: 26,
    marginBottom: 20,
  },
  fileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.highlight,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  fileIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  fileInfo: {
    flex: 1,
  },
  fileName: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  fileAction: {
    fontSize: 12,
    color: colors.primary,
  },
});
