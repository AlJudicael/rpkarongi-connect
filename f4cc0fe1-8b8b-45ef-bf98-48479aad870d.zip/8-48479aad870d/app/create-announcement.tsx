
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import { Footer } from '@/components/Footer';
import { CollapsibleSidebar } from '@/components/CollapsibleSidebar';
import { getAnnouncements, saveAnnouncements } from '@/utils/storage';
import { Announcement, Trade } from '@/types';
import { Picker } from '@react-native-picker/picker';
import * as DocumentPicker from 'expo-document-picker';

export default function CreateAnnouncementScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedTrades, setSelectedTrades] = useState<Trade[]>([]);
  const [file, setFile] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const trades: Trade[] = ['IT', 'EEE', 'AUTO-MOBILE TECH', 'MANUFACTURING TECHNOLOGY', 'HOSPITALITY', 'HORTICULTURE'];

  const handlePickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/*'],
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        setFile(result.assets[0]);
      }
    } catch (error) {
      console.error('Error picking document:', error);
      Alert.alert('Error', 'Failed to pick document');
    }
  };

  const handleSubmit = async () => {
    if (!title.trim() || !content.trim()) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    if (!user) return;

    setLoading(true);
    try {
      const announcements = await getAnnouncements();
      const newAnnouncement: Announcement = {
        id: Date.now().toString(),
        title: title.trim(),
        content: content.trim(),
        fileUrl: file?.uri,
        fileName: file?.name,
        fileType: file?.mimeType,
        createdBy: user.id,
        createdByName: `${user.firstName} ${user.lastName}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        targetTrades: selectedTrades.length > 0 ? selectedTrades : undefined,
      };

      announcements.push(newAnnouncement);
      await saveAnnouncements(announcements);

      Alert.alert('Success', 'Announcement created successfully', [
        { text: 'OK', onPress: () => router.back() }
      ]);
    } catch (error) {
      console.error('Error creating announcement:', error);
      Alert.alert('Error', 'Failed to create announcement');
    } finally {
      setLoading(false);
    }
  };

  const toggleTrade = (trade: Trade) => {
    setSelectedTrades(prev => 
      prev.includes(trade) 
        ? prev.filter(t => t !== trade)
        : [...prev, trade]
    );
  };

  if (!user || (user.role !== 'admin' && user.role !== 'staff')) {
    router.replace('/dashboard');
    return null;
  }

  return (
    <View style={styles.container}>
      <View style={styles.mainContent}>
        <CollapsibleSidebar />
        
        <View style={styles.content}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
              <IconSymbol name="chevron.left" size={24} color={colors.primary} />
            </TouchableOpacity>
            <Text style={styles.title}>Create Announcement</Text>
          </View>

          <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
            <View style={styles.form}>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Title *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter announcement title"
                  placeholderTextColor={colors.textSecondary}
                  value={title}
                  onChangeText={setTitle}
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Content *</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Enter announcement content"
                  placeholderTextColor={colors.textSecondary}
                  value={content}
                  onChangeText={setContent}
                  multiline
                  numberOfLines={8}
                  textAlignVertical="top"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Target Trades (Optional)</Text>
                <Text style={styles.helperText}>Leave empty to send to all trades</Text>
                <View style={styles.tradesContainer}>
                  {trades.map((trade) => (
                    <TouchableOpacity
                      key={trade}
                      style={[
                        styles.tradeChip,
                        selectedTrades.includes(trade) && styles.tradeChipSelected
                      ]}
                      onPress={() => toggleTrade(trade)}
                    >
                      <Text style={[
                        styles.tradeChipText,
                        selectedTrades.includes(trade) && styles.tradeChipTextSelected
                      ]}>
                        {trade}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Attachment (Optional)</Text>
                <TouchableOpacity style={styles.fileButton} onPress={handlePickDocument}>
                  <IconSymbol name="paperclip" size={20} color={colors.primary} />
                  <Text style={styles.fileButtonText}>
                    {file ? file.name : 'Pick a file (PDF or Image)'}
                  </Text>
                </TouchableOpacity>
                {file && (
                  <TouchableOpacity
                    style={styles.removeFileButton}
                    onPress={() => setFile(null)}
                  >
                    <IconSymbol name="xmark.circle.fill" size={20} color={colors.danger} />
                    <Text style={styles.removeFileText}>Remove file</Text>
                  </TouchableOpacity>
                )}
              </View>

              <TouchableOpacity
                style={[styles.submitButton, loading && styles.submitButtonDisabled]}
                onPress={handleSubmit}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <>
                    <IconSymbol name="checkmark.circle.fill" size={20} color="#ffffff" />
                    <Text style={styles.submitButtonText}>Create Announcement</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </View>
      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: 16,
  },
  backButton: {
    padding: 4,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
  },
  scrollView: {
    flex: 1,
  },
  form: {
    padding: 20,
    gap: 24,
  },
  inputContainer: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  helperText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  input: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    color: colors.text,
  },
  textArea: {
    minHeight: 150,
    paddingTop: 12,
  },
  tradesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  tradeChip: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
  },
  tradeChipSelected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  tradeChipText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.text,
  },
  tradeChipTextSelected: {
    color: '#ffffff',
  },
  fileButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  fileButtonText: {
    fontSize: 14,
    color: colors.text,
    flex: 1,
  },
  removeFileButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  removeFileText: {
    fontSize: 14,
    color: colors.danger,
    fontWeight: '600',
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    marginTop: 16,
    boxShadow: `0px 4px 12px ${colors.shadow}`,
    elevation: 5,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#ffffff',
  },
});
