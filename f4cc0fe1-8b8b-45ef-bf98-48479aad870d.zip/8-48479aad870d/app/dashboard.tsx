
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import { Footer } from '@/components/Footer';
import { CollapsibleSidebar } from '@/components/CollapsibleSidebar';
import { getAnnouncements, getTimetables, getSchedules, getUsers } from '@/utils/storage';
import { Announcement, Timetable, Schedule } from '@/types';
import Animated, { FadeInDown } from 'react-native-reanimated';

const { width } = Dimensions.get('window');

export default function DashboardScreen() {
  const router = useRouter();
  const { user, loading } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [timetables, setTimetables] = useState<Timetable[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [userCount, setUserCount] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      router.replace('/');
    } else if (user) {
      loadDashboardData();
    }
  }, [user, loading]);

  const loadDashboardData = async () => {
    try {
      const [announcementsData, timetablesData, schedulesData, usersData] = await Promise.all([
        getAnnouncements(),
        getTimetables(),
        getSchedules(),
        getUsers(),
      ]);

      setAnnouncements(announcementsData);
      setTimetables(timetablesData);
      setSchedules(schedulesData);
      setUserCount(usersData.length);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  if (loading || !user) {
    return null;
  }

  const getUpcomingSchedules = () => {
    const today = new Date();
    return schedules
      .filter(s => {
        if (!user.trade && user.role === 'student') return false;
        if (user.role === 'student' && s.trade !== user.trade) return false;
        const scheduleDate = new Date(s.date);
        return scheduleDate >= today;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 3);
  };

  const getTodayTimetable = () => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const today = days[new Date().getDay()];
    
    return timetables
      .filter(t => {
        if (!user.trade && user.role === 'student') return false;
        if (user.role === 'student' && t.trade !== user.trade) return false;
        return t.day === today;
      })
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
  };

  const getRelevantAnnouncements = () => {
    return announcements
      .filter(a => {
        if (!a.targetTrades || a.targetTrades.length === 0) return true;
        if (user.role === 'admin') return true;
        if (user.role === 'staff' || user.role === 'student') {
          return user.trade && a.targetTrades.includes(user.trade);
        }
        return true;
      })
      .slice(0, 5);
  };

  const upcomingSchedules = getUpcomingSchedules();
  const todayClasses = getTodayTimetable();
  const relevantAnnouncements = getRelevantAnnouncements();

  return (
    <View style={styles.container}>
      <View style={styles.mainContent}>
        <CollapsibleSidebar />
        
        <ScrollView 
          style={styles.content}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
          }
        >
          <View style={styles.header}>
            <View>
              <Text style={styles.greeting}>Welcome back,</Text>
              <Text style={styles.userName}>{user.firstName} {user.lastName}</Text>
              <Text style={styles.userRole}>{user.role.toUpperCase()}{user.trade ? ` - ${user.trade}` : ''}</Text>
            </View>
          </View>

          <View style={styles.statsContainer}>
            <Animated.View entering={FadeInDown.delay(100).springify()} style={styles.statCard}>
              <View style={[styles.statIcon, { backgroundColor: colors.primary + '20' }]}>
                <IconSymbol name="megaphone.fill" size={24} color={colors.primary} />
              </View>
              <Text style={styles.statValue}>{announcements.length}</Text>
              <Text style={styles.statLabel}>Announcements</Text>
            </Animated.View>

            <Animated.View entering={FadeInDown.delay(200).springify()} style={styles.statCard}>
              <View style={[styles.statIcon, { backgroundColor: colors.accent + '20' }]}>
                <IconSymbol name="calendar" size={24} color={colors.accent} />
              </View>
              <Text style={styles.statValue}>{todayClasses.length}</Text>
              <Text style={styles.statLabel}>Today&apos;s Classes</Text>
            </Animated.View>

            <Animated.View entering={FadeInDown.delay(300).springify()} style={styles.statCard}>
              <View style={[styles.statIcon, { backgroundColor: colors.success + '20' }]}>
                <IconSymbol name="clock.fill" size={24} color={colors.success} />
              </View>
              <Text style={styles.statValue}>{upcomingSchedules.length}</Text>
              <Text style={styles.statLabel}>Upcoming Events</Text>
            </Animated.View>

            {user.role === 'admin' && (
              <Animated.View entering={FadeInDown.delay(400).springify()} style={styles.statCard}>
                <View style={[styles.statIcon, { backgroundColor: colors.info + '20' }]}>
                  <IconSymbol name="person.3.fill" size={24} color={colors.info} />
                </View>
                <Text style={styles.statValue}>{userCount}</Text>
                <Text style={styles.statLabel}>Total Users</Text>
              </Animated.View>
            )}
          </View>

          <Animated.View entering={FadeInDown.delay(500).springify()} style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Recent Announcements</Text>
              <TouchableOpacity onPress={() => router.push('/announcements')}>
                <Text style={styles.seeAll}>See All</Text>
              </TouchableOpacity>
            </View>
            {relevantAnnouncements.length > 0 ? (
              relevantAnnouncements.map((announcement, index) => (
                <TouchableOpacity
                  key={announcement.id}
                  style={styles.announcementItem}
                  onPress={() => router.push(`/announcement-detail?id=${announcement.id}` as any)}
                >
                  <View style={styles.announcementIcon}>
                    <IconSymbol name="megaphone.fill" size={20} color={colors.primary} />
                  </View>
                  <View style={styles.announcementContent}>
                    <Text style={styles.announcementTitle} numberOfLines={1}>
                      {announcement.title}
                    </Text>
                    <Text style={styles.announcementMeta}>
                      {announcement.createdByName} • {new Date(announcement.createdAt).toLocaleDateString()}
                    </Text>
                  </View>
                  <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
                </TouchableOpacity>
              ))
            ) : (
              <Text style={styles.emptyText}>No announcements yet</Text>
            )}
          </Animated.View>

          <Animated.View entering={FadeInDown.delay(600).springify()} style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Today&apos;s Schedule</Text>
              <TouchableOpacity onPress={() => router.push('/timetable')}>
                <Text style={styles.seeAll}>View Full</Text>
              </TouchableOpacity>
            </View>
            {todayClasses.length > 0 ? (
              todayClasses.map((classItem, index) => (
                <View key={classItem.id} style={styles.classItem}>
                  <View style={styles.classTime}>
                    <Text style={styles.classTimeText}>{classItem.startTime}</Text>
                    <Text style={styles.classTimeText}>-</Text>
                    <Text style={styles.classTimeText}>{classItem.endTime}</Text>
                  </View>
                  <View style={styles.classDetails}>
                    <Text style={styles.classSubject}>{classItem.subject}</Text>
                    <Text style={styles.classMeta}>
                      {classItem.instructor} • Room {classItem.room}
                    </Text>
                  </View>
                </View>
              ))
            ) : (
              <Text style={styles.emptyText}>No classes scheduled for today</Text>
            )}
          </Animated.View>

          {upcomingSchedules.length > 0 && (
            <Animated.View entering={FadeInDown.delay(700).springify()} style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Upcoming Events</Text>
                <TouchableOpacity onPress={() => router.push('/schedule')}>
                  <Text style={styles.seeAll}>See All</Text>
                </TouchableOpacity>
              </View>
              {upcomingSchedules.map((schedule, index) => (
                <View key={schedule.id} style={styles.eventItem}>
                  <View style={styles.eventDate}>
                    <Text style={styles.eventDay}>
                      {new Date(schedule.date).getDate()}
                    </Text>
                    <Text style={styles.eventMonth}>
                      {new Date(schedule.date).toLocaleDateString('en-US', { month: 'short' })}
                    </Text>
                  </View>
                  <View style={styles.eventDetails}>
                    <Text style={styles.eventTitle}>{schedule.title}</Text>
                    <Text style={styles.eventMeta}>
                      {schedule.time} • {schedule.location}
                    </Text>
                  </View>
                </View>
              ))}
            </Animated.View>
          )}

          <View style={{ height: 40 }} />
        </ScrollView>
      </View>
      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  header: {
    marginBottom: 24,
  },
  greeting: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  userName: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.text,
    marginTop: 4,
  },
  userRole: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '600',
    marginTop: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    minWidth: width > 768 ? 150 : (width - 56) / 2,
    alignItems: 'center',
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 3,
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  seeAll: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '600',
  },
  announcementItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 2,
  },
  announcementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  announcementContent: {
    flex: 1,
  },
  announcementTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  announcementMeta: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  classItem: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 2,
  },
  classTime: {
    alignItems: 'center',
    marginRight: 16,
    paddingRight: 16,
    borderRightWidth: 2,
    borderRightColor: colors.primary,
  },
  classTimeText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  classDetails: {
    flex: 1,
  },
  classSubject: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  classMeta: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  eventItem: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 2,
  },
  eventDate: {
    width: 60,
    height: 60,
    borderRadius: 12,
    backgroundColor: colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  eventDay: {
    fontSize: 24,
    fontWeight: '800',
    color: '#ffffff',
  },
  eventMonth: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
  },
  eventDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  eventTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  eventMeta: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  emptyText: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    padding: 20,
  },
});
