
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import { Footer } from '@/components/Footer';
import { CollapsibleSidebar } from '@/components/CollapsibleSidebar';
import { getUsers } from '@/utils/storage';
import { User } from '@/types';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function StudentsScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const [students, setStudents] = useState<User[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!user || (user.role !== 'admin' && user.role !== 'staff')) {
      router.replace('/dashboard');
    } else {
      loadStudents();
    }
  }, [user]);

  const loadStudents = async () => {
    try {
      const allUsers = await getUsers();
      const studentUsers = allUsers.filter(u => {
        if (u.role !== 'student') return false;
        if (user?.role === 'staff') {
          return u.trade === user.trade;
        }
        return true;
      });
      setStudents(studentUsers.sort((a, b) => (a.registrationNumber || '').localeCompare(b.registrationNumber || '')));
    } catch (error) {
      console.error('Error loading students:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadStudents();
    setRefreshing(false);
  };

  if (!user || (user.role !== 'admin' && user.role !== 'staff')) return null;

  const studentsByTrade = students.reduce((acc, student) => {
    const trade = student.trade || 'Unknown';
    if (!acc[trade]) acc[trade] = [];
    acc[trade].push(student);
    return acc;
  }, {} as Record<string, User[]>);

  return (
    <View style={styles.container}>
      <View style={styles.mainContent}>
        <CollapsibleSidebar />
        
        <View style={styles.content}>
          <View style={styles.header}>
            <View>
              <Text style={styles.title}>Students</Text>
              <Text style={styles.subtitle}>
                {user.role === 'staff' ? `${user.trade} Trade Students` : 'All Students'}
              </Text>
            </View>
            <View style={styles.countBadge}>
              <Text style={styles.countText}>{students.length}</Text>
            </View>
          </View>

          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
            }
          >
            {Object.keys(studentsByTrade).length > 0 ? (
              Object.entries(studentsByTrade).map(([trade, tradeStudents], tradeIndex) => (
                <View key={trade} style={styles.tradeSection}>
                  <View style={styles.tradeSectionHeader}>
                    <Text style={styles.tradeSectionTitle}>{trade}</Text>
                    <Text style={styles.tradeSectionCount}>{tradeStudents.length} students</Text>
                  </View>
                  {tradeStudents.map((student, index) => (
                    <Animated.View
                      key={student.id}
                      entering={FadeInDown.delay((tradeIndex * 100) + (index * 50)).springify()}
                      style={styles.studentCard}
                    >
                      <View style={styles.studentAvatar}>
                        <Text style={styles.studentAvatarText}>
                          {student.firstName[0]}{student.lastName[0]}
                        </Text>
                      </View>
                      <View style={styles.studentInfo}>
                        <Text style={styles.studentName}>
                          {student.firstName} {student.lastName}
                        </Text>
                        <Text style={styles.studentEmail}>{student.email}</Text>
                        {student.registrationNumber && (
                          <View style={styles.regBadge}>
                            <IconSymbol name="number" size={12} color={colors.primary} />
                            <Text style={styles.regText}>{student.registrationNumber}</Text>
                          </View>
                        )}
                      </View>
                      <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
                    </Animated.View>
                  ))}
                </View>
              ))
            ) : (
              <View style={styles.emptyContainer}>
                <IconSymbol name="person.2.fill" size={64} color={colors.textSecondary} />
                <Text style={styles.emptyText}>No students found</Text>
              </View>
            )}
            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </View>
      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  countBadge: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  countText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#ffffff',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  tradeSection: {
    marginBottom: 24,
  },
  tradeSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingBottom: 8,
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
  },
  tradeSectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  tradeSectionCount: {
    fontSize: 14,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  studentCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 3,
  },
  studentAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.success,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  studentAvatarText: {
    fontSize: 18,
    fontWeight: '800',
    color: '#ffffff',
  },
  studentInfo: {
    flex: 1,
  },
  studentName: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  studentEmail: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 6,
  },
  regBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  regText: {
    fontSize: 12,
    color: colors.primary,
    fontWeight: '600',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 16,
  },
});
