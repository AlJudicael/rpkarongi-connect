
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, Alert, TextInput, Modal } from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import { Footer } from '@/components/Footer';
import { CollapsibleSidebar } from '@/components/CollapsibleSidebar';
import { getSchedules, saveSchedules } from '@/utils/storage';
import { Schedule, Trade } from '@/types';
import { Picker } from '@react-native-picker/picker';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function ScheduleScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    trade: (user?.trade || 'IT') as Trade,
    title: '',
    description: '',
    date: '',
    time: '',
    location: '',
  });

  const trades: Trade[] = ['IT', 'EEE', 'AUTO-MOBILE TECH', 'MANUFACTURING TECHNOLOGY', 'HOSPITALITY', 'HORTICULTURE'];

  useEffect(() => {
    if (!user) {
      router.replace('/');
    } else {
      loadSchedules();
    }
  }, [user]);

  const loadSchedules = async () => {
    try {
      const data = await getSchedules();
      const filtered = data.filter(s => {
        if (user?.role === 'admin') return true;
        if (user?.role === 'staff' || user?.role === 'student') {
          return user.trade && s.trade === user.trade;
        }
        return true;
      });
      setSchedules(filtered.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
    } catch (error) {
      console.error('Error loading schedules:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadSchedules();
    setRefreshing(false);
  };

  const handleCreateSchedule = async () => {
    if (!formData.title || !formData.date || !formData.time || !formData.location) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    if (!user) return;

    try {
      const allSchedules = await getSchedules();
      const newSchedule: Schedule = {
        id: Date.now().toString(),
        trade: formData.trade,
        title: formData.title,
        description: formData.description,
        date: formData.date,
        time: formData.time,
        location: formData.location,
        createdBy: user.id,
        createdAt: new Date().toISOString(),
      };

      allSchedules.push(newSchedule);
      await saveSchedules(allSchedules);
      await loadSchedules();
      setShowModal(false);
      setFormData({
        trade: (user?.trade || 'IT') as Trade,
        title: '',
        description: '',
        date: '',
        time: '',
        location: '',
      });
      Alert.alert('Success', 'Schedule created successfully');
    } catch (error) {
      console.error('Error creating schedule:', error);
      Alert.alert('Error', 'Failed to create schedule');
    }
  };

  if (!user) return null;

  const canManageSchedule = user.role === 'admin' || user.role === 'staff';

  return (
    <View style={styles.container}>
      <View style={styles.mainContent}>
        <CollapsibleSidebar />
        
        <View style={styles.content}>
          <View style={styles.header}>
            <View>
              <Text style={styles.title}>Schedule</Text>
              <Text style={styles.subtitle}>Upcoming events and activities</Text>
            </View>
            {canManageSchedule && (
              <TouchableOpacity
                style={styles.createButton}
                onPress={() => setShowModal(true)}
              >
                <IconSymbol name="plus" size={20} color="#ffffff" />
                <Text style={styles.createButtonText}>Add Event</Text>
              </TouchableOpacity>
            )}
          </View>

          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
            }
          >
            {schedules.length > 0 ? (
              schedules.map((schedule, index) => (
                <Animated.View
                  key={schedule.id}
                  entering={FadeInDown.delay(index * 100).springify()}
                  style={styles.scheduleCard}
                >
                  <View style={styles.dateSection}>
                    <Text style={styles.day}>{new Date(schedule.date).getDate()}</Text>
                    <Text style={styles.month}>
                      {new Date(schedule.date).toLocaleDateString('en-US', { month: 'short' })}
                    </Text>
                  </View>
                  <View style={styles.detailsSection}>
                    <Text style={styles.scheduleTitle}>{schedule.title}</Text>
                    {schedule.description && (
                      <Text style={styles.description}>{schedule.description}</Text>
                    )}
                    <View style={styles.metaRow}>
                      <View style={styles.metaItem}>
                        <IconSymbol name="clock.fill" size={14} color={colors.textSecondary} />
                        <Text style={styles.metaText}>{schedule.time}</Text>
                      </View>
                      <View style={styles.metaItem}>
                        <IconSymbol name="location.fill" size={14} color={colors.textSecondary} />
                        <Text style={styles.metaText}>{schedule.location}</Text>
                      </View>
                    </View>
                    <View style={styles.tradeBadge}>
                      <Text style={styles.tradeText}>{schedule.trade}</Text>
                    </View>
                  </View>
                </Animated.View>
              ))
            ) : (
              <View style={styles.emptyContainer}>
                <IconSymbol name="calendar" size={64} color={colors.textSecondary} />
                <Text style={styles.emptyText}>No scheduled events</Text>
              </View>
            )}
            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </View>

      <Modal visible={showModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Schedule Event</Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <IconSymbol name="xmark.circle.fill" size={28} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
              <View style={styles.modalForm}>
                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Trade</Text>
                  <View style={styles.pickerWrapper}>
                    <Picker
                      selectedValue={formData.trade}
                      onValueChange={(value) => setFormData({ ...formData, trade: value as Trade })}
                      style={styles.picker}
                    >
                      {trades.map((trade) => (
                        <Picker.Item key={trade} label={trade} value={trade} />
                      ))}
                    </Picker>
                  </View>
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Title *</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Event title"
                    placeholderTextColor={colors.textSecondary}
                    value={formData.title}
                    onChangeText={(text) => setFormData({ ...formData, title: text })}
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Description</Text>
                  <TextInput
                    style={[styles.input, styles.textArea]}
                    placeholder="Event description"
                    placeholderTextColor={colors.textSecondary}
                    value={formData.description}
                    onChangeText={(text) => setFormData({ ...formData, description: text })}
                    multiline
                    numberOfLines={3}
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Date * (YYYY-MM-DD)</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="2025-01-15"
                    placeholderTextColor={colors.textSecondary}
                    value={formData.date}
                    onChangeText={(text) => setFormData({ ...formData, date: text })}
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Time *</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="10:00 AM"
                    placeholderTextColor={colors.textSecondary}
                    value={formData.time}
                    onChangeText={(text) => setFormData({ ...formData, time: text })}
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Location *</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Event location"
                    placeholderTextColor={colors.textSecondary}
                    value={formData.location}
                    onChangeText={(text) => setFormData({ ...formData, location: text })}
                  />
                </View>

                <TouchableOpacity style={styles.submitButton} onPress={handleCreateSchedule}>
                  <Text style={styles.submitButtonText}>Add Event</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    gap: 8,
  },
  createButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  scheduleCard: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 3,
  },
  dateSection: {
    width: 60,
    height: 60,
    borderRadius: 12,
    backgroundColor: colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  day: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
  },
  month: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.text,
  },
  detailsSection: {
    flex: 1,
  },
  scheduleTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
  },
  metaRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 8,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  tradeBadge: {
    alignSelf: 'flex-start',
    backgroundColor: colors.primary,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  tradeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#ffffff',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.card,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  modalScroll: {
    maxHeight: 500,
  },
  modalForm: {
    padding: 20,
    gap: 16,
  },
  inputContainer: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  input: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    color: colors.text,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  pickerWrapper: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    overflow: 'hidden',
  },
  picker: {
    height: 50,
    color: colors.text,
  },
  submitButton: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#ffffff',
  },
});
