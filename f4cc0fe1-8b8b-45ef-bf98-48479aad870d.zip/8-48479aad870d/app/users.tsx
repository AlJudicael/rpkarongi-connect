
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import { Footer } from '@/components/Footer';
import { CollapsibleSidebar } from '@/components/CollapsibleSidebar';
import { getUsers, saveUsers } from '@/utils/storage';
import { User } from '@/types';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function UsersScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      router.replace('/dashboard');
    } else {
      loadUsers();
    }
  }, [user]);

  const loadUsers = async () => {
    try {
      const data = await getUsers();
      setUsers(data.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadUsers();
    setRefreshing(false);
  };

  const handleDeleteUser = async (userId: string) => {
    Alert.alert(
      'Delete User',
      'Are you sure you want to delete this user?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const allUsers = await getUsers();
              const updated = allUsers.filter(u => u.id !== userId);
              await saveUsers(updated);
              await loadUsers();
              Alert.alert('Success', 'User deleted successfully');
            } catch (error) {
              console.error('Error deleting user:', error);
              Alert.alert('Error', 'Failed to delete user');
            }
          },
        },
      ]
    );
  };

  if (!user || user.role !== 'admin') return null;

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return colors.danger;
      case 'staff': return colors.primary;
      case 'student': return colors.success;
      default: return colors.secondary;
    }
  };

  const usersByRole = {
    admin: users.filter(u => u.role === 'admin'),
    staff: users.filter(u => u.role === 'staff'),
    student: users.filter(u => u.role === 'student'),
  };

  return (
    <View style={styles.container}>
      <View style={styles.mainContent}>
        <CollapsibleSidebar />
        
        <View style={styles.content}>
          <View style={styles.header}>
            <View>
              <Text style={styles.title}>User Management</Text>
              <Text style={styles.subtitle}>Manage all system users</Text>
            </View>
          </View>

          <View style={styles.statsContainer}>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{usersByRole.admin.length}</Text>
              <Text style={styles.statLabel}>Admins</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{usersByRole.staff.length}</Text>
              <Text style={styles.statLabel}>Staff</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{usersByRole.student.length}</Text>
              <Text style={styles.statLabel}>Students</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{users.length}</Text>
              <Text style={styles.statLabel}>Total</Text>
            </View>
          </View>

          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
            }
          >
            {users.length > 0 ? (
              users.map((userItem, index) => (
                <Animated.View
                  key={userItem.id}
                  entering={FadeInDown.delay(index * 50).springify()}
                  style={styles.userCard}
                >
                  <View style={styles.userAvatar}>
                    <Text style={styles.userAvatarText}>
                      {userItem.firstName[0]}{userItem.lastName[0]}
                    </Text>
                  </View>
                  <View style={styles.userInfo}>
                    <Text style={styles.userName}>
                      {userItem.firstName} {userItem.lastName}
                    </Text>
                    <Text style={styles.userEmail}>{userItem.email}</Text>
                    <View style={styles.userMeta}>
                      <View style={[styles.roleBadge, { backgroundColor: getRoleColor(userItem.role) }]}>
                        <Text style={styles.roleText}>{userItem.role.toUpperCase()}</Text>
                      </View>
                      {userItem.trade && (
                        <View style={styles.tradeBadge}>
                          <Text style={styles.tradeText}>{userItem.trade}</Text>
                        </View>
                      )}
                      {userItem.registrationNumber && (
                        <Text style={styles.regNumber}>{userItem.registrationNumber}</Text>
                      )}
                    </View>
                  </View>
                  {userItem.id !== user.id && (
                    <TouchableOpacity
                      style={styles.deleteButton}
                      onPress={() => handleDeleteUser(userItem.id)}
                    >
                      <IconSymbol name="trash.fill" size={20} color={colors.danger} />
                    </TouchableOpacity>
                  )}
                </Animated.View>
              ))
            ) : (
              <View style={styles.emptyContainer}>
                <IconSymbol name="person.3.fill" size={64} color={colors.textSecondary} />
                <Text style={styles.emptyText}>No users found</Text>
              </View>
            )}
            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </View>
      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  content: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 3,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 3,
  },
  userAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  userAvatarText: {
    fontSize: 18,
    fontWeight: '800',
    color: '#ffffff',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
  },
  userMeta: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    alignItems: 'center',
  },
  roleBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  roleText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#ffffff',
  },
  tradeBadge: {
    backgroundColor: colors.accent,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  tradeText: {
    fontSize: 10,
    fontWeight: '600',
    color: colors.text,
  },
  regNumber: {
    fontSize: 12,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  deleteButton: {
    padding: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 16,
  },
});
