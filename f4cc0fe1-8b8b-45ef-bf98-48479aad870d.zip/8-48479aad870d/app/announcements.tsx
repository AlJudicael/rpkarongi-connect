
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import { Footer } from '@/components/Footer';
import { CollapsibleSidebar } from '@/components/CollapsibleSidebar';
import { AnnouncementCard } from '@/components/AnnouncementCard';
import { getAnnouncements, saveAnnouncements } from '@/utils/storage';
import { Announcement } from '@/types';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function AnnouncementsScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!user) {
      router.replace('/');
    } else {
      loadAnnouncements();
    }
  }, [user]);

  const loadAnnouncements = async () => {
    try {
      const data = await getAnnouncements();
      const filtered = data.filter(a => {
        if (!a.targetTrades || a.targetTrades.length === 0) return true;
        if (user?.role === 'admin') return true;
        if ((user?.role === 'staff' || user?.role === 'student') && user.trade) {
          return a.targetTrades.includes(user.trade);
        }
        return true;
      });
      setAnnouncements(filtered.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ));
    } catch (error) {
      console.error('Error loading announcements:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadAnnouncements();
    setRefreshing(false);
  };

  const handleDelete = async (id: string) => {
    try {
      const allAnnouncements = await getAnnouncements();
      const updated = allAnnouncements.filter(a => a.id !== id);
      await saveAnnouncements(updated);
      await loadAnnouncements();
      Alert.alert('Success', 'Announcement deleted successfully');
    } catch (error) {
      console.error('Error deleting announcement:', error);
      Alert.alert('Error', 'Failed to delete announcement');
    }
  };

  if (!user) return null;

  const canCreateAnnouncement = user.role === 'admin' || user.role === 'staff';
  const canDeleteAnnouncement = user.role === 'admin';

  return (
    <View style={styles.container}>
      <View style={styles.mainContent}>
        <CollapsibleSidebar />
        
        <View style={styles.content}>
          <View style={styles.header}>
            <View>
              <Text style={styles.title}>Announcements</Text>
              <Text style={styles.subtitle}>Stay updated with the latest news</Text>
            </View>
            {canCreateAnnouncement && (
              <TouchableOpacity
                style={styles.createButton}
                onPress={() => router.push('/create-announcement')}
              >
                <IconSymbol name="plus" size={20} color="#ffffff" />
                <Text style={styles.createButtonText}>Create</Text>
              </TouchableOpacity>
            )}
          </View>

          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
            }
          >
            {announcements.length > 0 ? (
              announcements.map((announcement, index) => (
                <AnnouncementCard
                  key={announcement.id}
                  announcement={announcement}
                  index={index}
                  onPress={() => router.push(`/announcement-detail?id=${announcement.id}` as any)}
                  onDelete={() => handleDelete(announcement.id)}
                  canDelete={canDeleteAnnouncement}
                />
              ))
            ) : (
              <Animated.View entering={FadeInDown.springify()} style={styles.emptyContainer}>
                <IconSymbol name="megaphone" size={64} color={colors.textSecondary} />
                <Text style={styles.emptyText}>No announcements yet</Text>
                {canCreateAnnouncement && (
                  <TouchableOpacity
                    style={styles.emptyButton}
                    onPress={() => router.push('/create-announcement')}
                  >
                    <Text style={styles.emptyButtonText}>Create First Announcement</Text>
                  </TouchableOpacity>
                )}
              </Animated.View>
            )}
            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </View>
      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    gap: 8,
  },
  createButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 16,
    marginBottom: 24,
  },
  emptyButton: {
    backgroundColor: colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  emptyButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
});
