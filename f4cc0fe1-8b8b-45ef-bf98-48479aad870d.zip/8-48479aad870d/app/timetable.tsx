
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, Alert, TextInput, Modal } from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import { Footer } from '@/components/Footer';
import { CollapsibleSidebar } from '@/components/CollapsibleSidebar';
import { getTimetables, saveTimetables } from '@/utils/storage';
import { Timetable, Trade } from '@/types';
import { Picker } from '@react-native-picker/picker';
import Animated, { FadeInDown } from 'react-native-reanimated';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function TimetableScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const [timetables, setTimetables] = useState<Timetable[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedDay, setSelectedDay] = useState(DAYS[new Date().getDay() - 1] || 'Monday');
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    trade: (user?.trade || 'IT') as Trade,
    day: 'Monday',
    startTime: '',
    endTime: '',
    subject: '',
    instructor: '',
    room: '',
  });

  const trades: Trade[] = ['IT', 'EEE', 'AUTO-MOBILE TECH', 'MANUFACTURING TECHNOLOGY', 'HOSPITALITY', 'HORTICULTURE'];

  useEffect(() => {
    if (!user) {
      router.replace('/');
    } else {
      loadTimetables();
    }
  }, [user]);

  const loadTimetables = async () => {
    try {
      const data = await getTimetables();
      const filtered = data.filter(t => {
        if (user?.role === 'admin') return true;
        if (user?.role === 'staff' || user?.role === 'student') {
          return user.trade && t.trade === user.trade;
        }
        return true;
      });
      setTimetables(filtered);
    } catch (error) {
      console.error('Error loading timetables:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTimetables();
    setRefreshing(false);
  };

  const handleCreateTimetable = async () => {
    if (!formData.startTime || !formData.endTime || !formData.subject || !formData.instructor || !formData.room) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    if (!user) return;

    try {
      const allTimetables = await getTimetables();
      const newTimetable: Timetable = {
        id: Date.now().toString(),
        trade: formData.trade,
        day: formData.day,
        startTime: formData.startTime,
        endTime: formData.endTime,
        subject: formData.subject,
        instructor: formData.instructor,
        room: formData.room,
        createdBy: user.id,
        createdAt: new Date().toISOString(),
      };

      allTimetables.push(newTimetable);
      await saveTimetables(allTimetables);
      await loadTimetables();
      setShowModal(false);
      setFormData({
        trade: (user?.trade || 'IT') as Trade,
        day: 'Monday',
        startTime: '',
        endTime: '',
        subject: '',
        instructor: '',
        room: '',
      });
      Alert.alert('Success', 'Timetable entry created successfully');
    } catch (error) {
      console.error('Error creating timetable:', error);
      Alert.alert('Error', 'Failed to create timetable entry');
    }
  };

  const handleDelete = async (id: string) => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this timetable entry?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const allTimetables = await getTimetables();
              const updated = allTimetables.filter(t => t.id !== id);
              await saveTimetables(updated);
              await loadTimetables();
              Alert.alert('Success', 'Timetable entry deleted');
            } catch (error) {
              console.error('Error deleting timetable:', error);
              Alert.alert('Error', 'Failed to delete entry');
            }
          },
        },
      ]
    );
  };

  if (!user) return null;

  const canManageTimetable = user.role === 'admin' || user.role === 'staff';
  const filteredByDay = timetables.filter(t => t.day === selectedDay).sort((a, b) => a.startTime.localeCompare(b.startTime));

  return (
    <View style={styles.container}>
      <View style={styles.mainContent}>
        <CollapsibleSidebar />
        
        <View style={styles.content}>
          <View style={styles.header}>
            <View>
              <Text style={styles.title}>Timetable</Text>
              <Text style={styles.subtitle}>Class schedule by day</Text>
            </View>
            {canManageTimetable && (
              <TouchableOpacity
                style={styles.createButton}
                onPress={() => setShowModal(true)}
              >
                <IconSymbol name="plus" size={20} color="#ffffff" />
                <Text style={styles.createButtonText}>Add Entry</Text>
              </TouchableOpacity>
            )}
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.daysScroll}
            contentContainerStyle={styles.daysContainer}
          >
            {DAYS.map((day) => (
              <TouchableOpacity
                key={day}
                style={[styles.dayChip, selectedDay === day && styles.dayChipSelected]}
                onPress={() => setSelectedDay(day)}
              >
                <Text style={[styles.dayText, selectedDay === day && styles.dayTextSelected]}>
                  {day}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
            }
          >
            {filteredByDay.length > 0 ? (
              filteredByDay.map((item, index) => (
                <Animated.View
                  key={item.id}
                  entering={FadeInDown.delay(index * 100).springify()}
                  style={styles.timetableCard}
                >
                  <View style={styles.timeSection}>
                    <Text style={styles.timeText}>{item.startTime}</Text>
                    <View style={styles.timeDivider} />
                    <Text style={styles.timeText}>{item.endTime}</Text>
                  </View>
                  <View style={styles.detailsSection}>
                    <Text style={styles.subject}>{item.subject}</Text>
                    <View style={styles.metaRow}>
                      <View style={styles.metaItem}>
                        <IconSymbol name="person.fill" size={14} color={colors.textSecondary} />
                        <Text style={styles.metaText}>{item.instructor}</Text>
                      </View>
                      <View style={styles.metaItem}>
                        <IconSymbol name="building.2.fill" size={14} color={colors.textSecondary} />
                        <Text style={styles.metaText}>Room {item.room}</Text>
                      </View>
                    </View>
                    <View style={styles.tradeBadge}>
                      <Text style={styles.tradeText}>{item.trade}</Text>
                    </View>
                  </View>
                  {canManageTimetable && (
                    <TouchableOpacity
                      style={styles.deleteButton}
                      onPress={() => handleDelete(item.id)}
                    >
                      <IconSymbol name="trash.fill" size={18} color={colors.danger} />
                    </TouchableOpacity>
                  )}
                </Animated.View>
              ))
            ) : (
              <View style={styles.emptyContainer}>
                <IconSymbol name="calendar" size={64} color={colors.textSecondary} />
                <Text style={styles.emptyText}>No classes scheduled for {selectedDay}</Text>
              </View>
            )}
            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </View>

      <Modal visible={showModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Timetable Entry</Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <IconSymbol name="xmark.circle.fill" size={28} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
              <View style={styles.modalForm}>
                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Trade</Text>
                  <View style={styles.pickerWrapper}>
                    <Picker
                      selectedValue={formData.trade}
                      onValueChange={(value) => setFormData({ ...formData, trade: value as Trade })}
                      style={styles.picker}
                    >
                      {trades.map((trade) => (
                        <Picker.Item key={trade} label={trade} value={trade} />
                      ))}
                    </Picker>
                  </View>
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Day</Text>
                  <View style={styles.pickerWrapper}>
                    <Picker
                      selectedValue={formData.day}
                      onValueChange={(value) => setFormData({ ...formData, day: value })}
                      style={styles.picker}
                    >
                      {DAYS.map((day) => (
                        <Picker.Item key={day} label={day} value={day} />
                      ))}
                    </Picker>
                  </View>
                </View>

                <View style={styles.row}>
                  <View style={[styles.inputContainer, styles.halfWidth]}>
                    <Text style={styles.label}>Start Time</Text>
                    <TextInput
                      style={styles.input}
                      placeholder="09:00"
                      placeholderTextColor={colors.textSecondary}
                      value={formData.startTime}
                      onChangeText={(text) => setFormData({ ...formData, startTime: text })}
                    />
                  </View>
                  <View style={[styles.inputContainer, styles.halfWidth]}>
                    <Text style={styles.label}>End Time</Text>
                    <TextInput
                      style={styles.input}
                      placeholder="11:00"
                      placeholderTextColor={colors.textSecondary}
                      value={formData.endTime}
                      onChangeText={(text) => setFormData({ ...formData, endTime: text })}
                    />
                  </View>
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Subject</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter subject name"
                    placeholderTextColor={colors.textSecondary}
                    value={formData.subject}
                    onChangeText={(text) => setFormData({ ...formData, subject: text })}
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Instructor</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter instructor name"
                    placeholderTextColor={colors.textSecondary}
                    value={formData.instructor}
                    onChangeText={(text) => setFormData({ ...formData, instructor: text })}
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Room</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter room number"
                    placeholderTextColor={colors.textSecondary}
                    value={formData.room}
                    onChangeText={(text) => setFormData({ ...formData, room: text })}
                  />
                </View>

                <TouchableOpacity style={styles.submitButton} onPress={handleCreateTimetable}>
                  <Text style={styles.submitButtonText}>Add Entry</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    gap: 8,
  },
  createButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  daysScroll: {
    maxHeight: 60,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  daysContainer: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 8,
  },
  dayChip: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
  },
  dayChipSelected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  dayText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  dayTextSelected: {
    color: '#ffffff',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  timetableCard: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    boxShadow: `0px 2px 8px ${colors.shadow}`,
    elevation: 3,
  },
  timeSection: {
    alignItems: 'center',
    marginRight: 16,
    paddingRight: 16,
    borderRightWidth: 2,
    borderRightColor: colors.primary,
  },
  timeText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.primary,
  },
  timeDivider: {
    width: 2,
    height: 8,
    backgroundColor: colors.primary,
    marginVertical: 4,
  },
  detailsSection: {
    flex: 1,
  },
  subject: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 8,
  },
  metaRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 8,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  tradeBadge: {
    alignSelf: 'flex-start',
    backgroundColor: colors.accent,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  tradeText: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.text,
  },
  deleteButton: {
    padding: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.card,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  modalScroll: {
    maxHeight: 500,
  },
  modalForm: {
    padding: 20,
    gap: 16,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  halfWidth: {
    flex: 1,
  },
  inputContainer: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  input: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    color: colors.text,
  },
  pickerWrapper: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    overflow: 'hidden',
  },
  picker: {
    height: 50,
    color: colors.text,
  },
  submitButton: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#ffffff',
  },
});
