
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User, Announcement, Timetable, Schedule } from '@/types';

const STORAGE_KEYS = {
  CURRENT_USER: '@rpkarongi_current_user',
  USERS: '@rpkarongi_users',
  ANNOUNCEMENTS: '@rpkarongi_announcements',
  TIMETABLES: '@rpkarongi_timetables',
  SCHEDULES: '@rpkarongi_schedules',
};

// User Management
export const saveCurrentUser = async (user: User | null): Promise<void> => {
  try {
    if (user) {
      await AsyncStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      await AsyncStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  } catch (error) {
    console.error('Error saving current user:', error);
    throw error;
  }
};

export const getCurrentUser = async (): Promise<User | null> => {
  try {
    const userJson = await AsyncStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return userJson ? JSON.parse(userJson) : null;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};

export const saveUsers = async (users: User[]): Promise<void> => {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  } catch (error) {
    console.error('Error saving users:', error);
    throw error;
  }
};

export const getUsers = async (): Promise<User[]> => {
  try {
    const usersJson = await AsyncStorage.getItem(STORAGE_KEYS.USERS);
    return usersJson ? JSON.parse(usersJson) : [];
  } catch (error) {
    console.error('Error getting users:', error);
    return [];
  }
};

// Announcement Management
export const saveAnnouncements = async (announcements: Announcement[]): Promise<void> => {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(announcements));
  } catch (error) {
    console.error('Error saving announcements:', error);
    throw error;
  }
};

export const getAnnouncements = async (): Promise<Announcement[]> => {
  try {
    const announcementsJson = await AsyncStorage.getItem(STORAGE_KEYS.ANNOUNCEMENTS);
    return announcementsJson ? JSON.parse(announcementsJson) : [];
  } catch (error) {
    console.error('Error getting announcements:', error);
    return [];
  }
};

// Timetable Management
export const saveTimetables = async (timetables: Timetable[]): Promise<void> => {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.TIMETABLES, JSON.stringify(timetables));
  } catch (error) {
    console.error('Error saving timetables:', error);
    throw error;
  }
};

export const getTimetables = async (): Promise<Timetable[]> => {
  try {
    const timetablesJson = await AsyncStorage.getItem(STORAGE_KEYS.TIMETABLES);
    return timetablesJson ? JSON.parse(timetablesJson) : [];
  } catch (error) {
    console.error('Error getting timetables:', error);
    return [];
  }
};

// Schedule Management
export const saveSchedules = async (schedules: Schedule[]): Promise<void> => {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));
  } catch (error) {
    console.error('Error saving schedules:', error);
    throw error;
  }
};

export const getSchedules = async (): Promise<Schedule[]> => {
  try {
    const schedulesJson = await AsyncStorage.getItem(STORAGE_KEYS.SCHEDULES);
    return schedulesJson ? JSON.parse(schedulesJson) : [];
  } catch (error) {
    console.error('Error getting schedules:', error);
    return [];
  }
};

// Clear all data
export const clearAllData = async (): Promise<void> => {
  try {
    await AsyncStorage.multiRemove([
      STORAGE_KEYS.CURRENT_USER,
      STORAGE_KEYS.USERS,
      STORAGE_KEYS.ANNOUNCEMENTS,
      STORAGE_KEYS.TIMETABLES,
      STORAGE_KEYS.SCHEDULES,
    ]);
  } catch (error) {
    console.error('Error clearing data:', error);
    throw error;
  }
};
